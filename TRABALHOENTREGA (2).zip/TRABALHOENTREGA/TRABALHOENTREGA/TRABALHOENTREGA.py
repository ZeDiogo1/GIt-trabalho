#!/usr/bin/env python3
# -- coding: latin-1 --

# bibliotecas
import requests
import json
import codecs
import sys
import csv
from datetime import datetime, timedelta
import tkinter as tk
from tkinter import messagebox
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import subprocess
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from tkinter import messagebox, Scrollbar, Text

# Defini��o da chave da API para acessar o servi�o OpenWeatherMap
chave_api = '7a80fb6664893d6bda2b44225f1692e0'

# Fun��o para obter coordenadas (latitude e longitude) a partir de uma localidade
def obter_coordenadas(localidade, chave_api):
    if ',' in localidade:
        latitude, longitude = localidade.split(',')
        return latitude.strip(), longitude.strip()
    else:
        url = f"http://api.openweathermap.org/data/2.5/weather?q={localidade}&appid={chave_api}"
        resposta = requests.get(url)
        dados = resposta.json()

        if resposta.status_code == 200:
            latitude = dados['coord']['lat']
            longitude = dados['coord']['lon']
            return latitude, longitude
        else:
            print("Localidade n�o encontrada. Por favor, tente novamente.")
            return None, None
        
# Fun��o para obter dados clim�ticos com base nas coordenadas
def obter_dados_climaticos(latitude, longitude, chave_api):
    url = f"http://api.openweathermap.org/data/2.5/weather?lat={latitude}&lon={longitude}&appid={chave_api}&units=metric"
    resposta = requests.get(url)
    dados = resposta.json()
    
    if resposta.status_code == 200:
        cidade = dados['name']
        regiao = dados['sys']['country']
        temperatura = dados['main']['temp']
        humidade = dados['main']['humidity']
        pressao = dados['main']['pressure']
        velocidade_vento = dados['wind']['speed']
        descricao = dados['weather'][0]['description']
        
        print(f"Condi��es clim�ticas em {cidade}, {regiao}:")
        print(f" - Temperatura: {temperatura}�C")
        print(f" - Humidade: {humidade}%")
        print(f" - Press�o Atmosf�rica: {pressao} hPa")
        print(f" - Velocidade do Vento: {velocidade_vento} m/s")
        print(f" - Descri��o: {descricao}") 
        
        now = datetime.now()
        data = str(now.strftime("%Y-%m-%d %H:%M:%S"))
        dados_para_guardar = [data, cidade, regiao, descricao, temperatura, humidade, pressao, velocidade_vento]
        guardar_historico(dados_para_guardar)
        
        dados_atuais = {
            'temperatura': temperatura,
            'descricao': descricao,
            'humidade': humidade,
            'pressao': pressao,
            'vento': velocidade_vento,
        }
        
        analisar_dados_climaticos(cidade, regiao, dados_atuais)

        return True
    else:
        return False
  
# Fun��o para analisar os dados clim�ticos e detectar condi��es an�malas    
def analisar_dados_climaticos(cidade, regiao, dados_atuais):
    registos = []
    with open("historico_de_usos.csv", 'r') as arquivo:
        leitor_csv = csv.reader(arquivo)
        for registo in leitor_csv:
            if len(registo) > 4 and registo[1] == cidade and registo[2] == regiao:
                registos.append(registo)

    mensagem_anomalia = detetar_anomalias(registos, dados_atuais)

    if registos and len(registos) > 1:
        ultimo_registo = registos[-2]
        print("-------------------------")
        print("�ltimo registro desta localidade:  ")
        print(ultimo_registo)
        print("-------------------------")
    else:
        print("Nenhum registro anterior encontrado para esta localidade.")

    if registos:
        temperatura = float(dados_atuais['temperatura'])
        humidade = float(dados_atuais['humidade'])
        pressao = float(dados_atuais['pressao'])
        velocidade_vento = float(dados_atuais['vento'])
        criar_interface(cidade, dados_atuais['descricao'], temperatura, humidade, pressao,  velocidade_vento, registos)

    # Verifica as condi��es e envia o email se necess�rio
    if detetar_furacoes(dados_atuais) or detetar_inundacoes(dados_atuais) or detetar_tornados(dados_atuais):
        enviar_email(email_do_utilizador, "ALERTA DE DESASTRE NATURAL", "A localidade inserida tem condi��es para estar sujeita a desastres naturais")
        print("Email enviado com sucesso")

# Fun��o para detectar anomalias nos dados clim�ticos
def detetar_anomalias(registos, dados_atuais):
    if not registos:
        return None

    ultimo_registo = registos[-2] if len(registos) > 1 else registos[-1]

    temperatura_anterior = float(ultimo_registo[4])
    humidade_anterior = float(ultimo_registo[5])
    pressao_anterior = float(ultimo_registo[6])
    velocidade_vento_anterior = float(ultimo_registo[7])

    novatemperatura = dados_atuais['temperatura']
    novahumidade = dados_atuais['humidade']
    novapressao = dados_atuais['pressao']
    novavelocidade_vento = dados_atuais['vento']

    mudancadetemp = 5
    mudancadehumidade = 7.5
    mudancadepressao = 10
    mudancadevelocidade_vento = 4

    anormal_temperatura = abs(novatemperatura - temperatura_anterior) >= mudancadetemp
    anormal_humidade = abs(novahumidade - humidade_anterior) >= mudancadehumidade
    anormal_pressao = abs(novapressao - pressao_anterior) >= mudancadepressao
    anormal_velocidade_vento = abs(novavelocidade_vento - velocidade_vento_anterior) >= mudancadevelocidade_vento

    if anormal_temperatura:
        print("Foi detetada uma varia��o abrupta de temperatura!")
    if anormal_pressao:
        print("Foi detetada uma varia��o abrupta de press�o atmosf�rica!")
    if anormal_humidade:
        print("Foi detetada uma varia��o abrupta de humidade!")
    if anormal_velocidade_vento:
        print("Foi detetada uma varia��o abrupta da velocidade do vento!")

    if detetar_furacoes(dados_atuais):
        print("H� condi��es para haver um furac�o nesta localidade")

    if detetar_inundacoes(dados_atuais):
        print("H� condi��es para haver uma inunda��o nesta localidade")

    if detetar_tornados(dados_atuais):
        print("H� condi��es para haver um tornado nesta localidade")

# Fun��o para detectar condi��es de furac�es
def detetar_furacoes(dados_atuais):
    temperatura = float(dados_atuais['temperatura'])
    humidade = float(dados_atuais['humidade'])

    if temperatura >= 0 and humidade >= 0:
        return True

    return False

# Fun��o para detectar condi��es de inunda��es
def detetar_inundacoes(dados_atuais):
    humidade = float(dados_atuais['humidade'])
    pressao = float(dados_atuais['pressao'])
    velocidade_vento = float(dados_atuais['vento'])

    if humidade >= 70 and velocidade_vento >= 6 and pressao >= 1015:
        return True

    return False

# Fun��o para detectar condi��es de tornados
def detetar_tornados(dados_atuais):
    temperatura = float(dados_atuais['temperatura'])
    humidade = float(dados_atuais['humidade'])
    pressao = float(dados_atuais['pressao'])
    velocidade_vento = float(dados_atuais['vento'])

    if temperatura > 20 and humidade >= 60 and pressao < 1000 and velocidade_vento >= 11:
        return True

    return False

# Fun��o para mostrar a interface de hist�rico  
def mostrar_historico_interface(frame_principal, frame_historico):
    try:
        with open("historico_de_usos.csv", "r") as arquivo:
            historico = arquivo.read()
            mostrar_historico(frame_principal, frame_historico, historico)
    except FileNotFoundError:
        messagebox.showerror("Erro", "Hist�rico n�o encontrado.")

# Fun��o para exibir o hist�rico na interface
def mostrar_historico(frame_principal, frame_historico, conteudo):
    frame_principal.pack_forget()
    frame_historico.pack(fill="both", expand=True)

    texto = Text(frame_historico, wrap="word", bg="#f0f0f0", fg="#000000")
    scrollbar = Scrollbar(frame_historico, command=texto.yview)
    texto.configure(yscrollcommand=scrollbar.set)
    texto.insert("1.0", conteudo)
    texto.pack(side="left", fill="both", expand=True)
    scrollbar.pack(side="right", fill="y")

# Fun��o para criar a interface gr�fica
def criar_interface(cidade, descricao, temperatura, humidade, pressao, velocidade_vento, registos):
    root = tk.Tk()
    root.title("Dados Clim�ticos")
    root.configure(bg="#282c34")

    frame_principal = tk.Frame(root, bg="#282c34")
    frame_principal.pack(fill="both", expand=True)

    frame_historico = tk.Frame(root, bg="#f0f0f0")

    label_cidade = tk.Label(frame_principal, text=f"Cidade: {cidade}", bg="#282c34", fg="#61dafb")
    label_cidade.pack()

    label_clima = tk.Label(frame_principal, text=f"Clima: {descricao}", bg="#282c34", fg="#61dafb")
    label_clima.pack()

    label_temperatura = tk.Label(frame_principal, text=f"Temperatura: {temperatura}�C", bg="#282c34", fg="#61dafb")
    label_temperatura.pack()

    label_humidade = tk.Label(frame_principal, text=f"Humidade: {humidade}%", bg="#282c34", fg="#61dafb")
    label_humidade.pack()

    label_pressao = tk.Label(frame_principal, text=f"Press�o: {pressao} mb", bg="#282c34", fg="#61dafb")
    label_pressao.pack()

    label_velocidade_vento = tk.Label(frame_principal, text=f"Velocidade do Vento: {velocidade_vento} m/s", bg="#282c34", fg="#61dafb")
    label_velocidade_vento.pack()

    datas = [datetime.strptime(registro[0], "%Y-%m-%d %H:%M:%S") for registro in registos]
    temperaturas = [float(registro[4]) for registro in registos]
    humidades = [float(registro[5]) for registro in registos]
    pressoes = [float(registro[6]) for registro in registos]
    velocidades_vento = [float(registro[7]) for registro in registos]

    fig, axs = plt.subplots(2, 2, figsize=(10, 8))

    axs[0, 0].plot(datas, temperaturas, marker='o', linestyle='-')
    axs[0, 0].set_title('Temperatura ao longo do tempo')
    axs[0, 0].set_xlabel('Data e Hora')
    axs[0, 0].set_ylabel('Temperatura (�C)')
    axs[0, 0].grid(True)

    axs[0, 1].plot(datas, humidades, marker='o', linestyle='-')
    axs[0, 1].set_title('Humidade ao longo do tempo')
    axs[0, 1].set_xlabel('Data e Hora')
    axs[0, 1].set_ylabel('Humidade (%)')
    axs[0, 1].grid(True)

    axs[1, 0].plot(datas, pressoes, marker='o', linestyle='-')
    axs[1, 0].set_title('Press�o ao longo do tempo')
    axs[1, 0].set_xlabel('Data e Hora')
    axs[1, 0].set_ylabel('Press�o (mb)')
    axs[1, 0].grid(True)

    axs[1, 1].plot(datas, velocidades_vento, marker='o', linestyle='-')
    axs[1, 1].set_title('Velocidade do Vento ao longo do tempo')
    axs[1, 1].set_xlabel('Data e Hora')
    axs[1, 1].set_ylabel('Velocidade do Vento (m/s)')
    axs[1, 1].grid(True)

    for ax in axs.flat:
        fig.autofmt_xdate()

    fig.tight_layout()
    canvas = FigureCanvasTkAgg(fig, master=frame_principal)
    canvas.draw()
    canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True)

    frame_botoes = tk.Frame(root, bg="#282c34")
    frame_botoes.pack(side=tk.BOTTOM, fill=tk.X)

    botao_historico = tk.Button(frame_botoes, text="Hist�rico", command=lambda: mostrar_historico_interface(frame_principal, frame_historico), bg="#61dafb", fg="#282c34")
    botao_historico.pack(side=tk.LEFT, padx=10)

    botao_voltar = tk.Button(frame_botoes, text="Voltar", command=lambda: [frame_historico.pack_forget(), frame_principal.pack(fill="both", expand=True)], bg="#61dafb", fg="#282c34")
    botao_voltar.pack(side=tk.RIGHT, padx=10)

    botao_fechar = tk.Button(frame_botoes, text="Fechar", command=root.quit, bg="#61dafb", fg="#282c34")
    botao_fechar.pack(side=tk.BOTTOM, pady=10)

    root.mainloop()

 # Fun��o para salvar dados clim�ticos em um arquivo CSV
def guardar_historico(dados):
    with open("historico_de_usos.csv", 'a') as arquivo:
        writer = csv.writer(arquivo, delimiter=',')
        writer.writerow(dados)

# Fun��o para solicitar o email do usu�rio
def solicitar_email():
    email = input("Por favor, insira o seu email: ")
    return email

# Fun��o para enviar email ao usu�ri
def enviar_email(destinatario, assunto, mensagem):
    remetente = 'testeemails038@gmail.com'
    senha = 'nzzv ngyu ryjz gmsg'

    # Configurando a mensagem
    msg = MIMEMultipart()
    msg['From'] = remetente
    msg['To'] = destinatario
    msg['Subject'] = assunto
    msg.attach(MIMEText(mensagem, 'plain'))

    try:
        # Conectando ao servidor SMTP do Gmail
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(remetente, senha)
        texto = msg.as_string()
        server.sendmail(remetente, destinatario, texto)
        server.quit()
        print(f"Email enviado com sucesso para {destinatario}")
    except Exception as e:
        print(f"Falha ao enviar o email. Erro: {e}")

# Fun��o principal para iniciar o programa
def iniciar_programa():
    global email_do_utilizador
    email_do_utilizador = solicitar_email()
    
    encontrado = False
    while not encontrado:
        cidade = input("Digite a localidade (cidade, pa�s): ")

        latitude, longitude = obter_coordenadas(cidade, chave_api)

        if latitude is not None and longitude is not None:
            encontrado = obter_dados_climaticos(latitude, longitude, chave_api)

# Executa a fun��o principal se o script for executado diretamente
if __name__ == "__main__":
    iniciar_programa()
